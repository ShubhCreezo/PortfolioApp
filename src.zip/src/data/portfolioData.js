export const portfolioData = {
    personal: {
      name: "Your Name",
      title: "Frontend Developer",
      email: "your.email@example.com",
      phone: "+1 (555) 123-4567",
      location: "Your City, State",
      bio: "Passionate frontend developer with a keen eye for creating responsive, user-friendly web applications. Experienced in React, JavaScript, and modern web technologies.",
      socialLinks: {
        github: "https://github.com/yourusername",
        linkedin: "https://linkedin.com/in/yourusername",
        portfolio: "https://yourportfolio.com"
      }
    },
    projects: [
      {
        id: 1,
        title: "E-Commerce Dashboard",
        description: "A responsive admin dashboard for managing products, orders, and customers with real-time analytics.",
        technologies: ["React", "JavaScript", "CSS Grid", "Chart.js"],
        github: "https://github.com/yourusername/ecommerce-dashboard",
        live: "https://ecommerce-dashboard-demo.com",
        image: "https://via.placeholder.com/400x250/4f46e5/white?text=E-Commerce+Dashboard",
        featured: true
      },
      {
        id: 2,
        title: "Weather App",
        description: "Interactive weather application with location-based forecasts and beautiful UI animations.",
        technologies: ["React", "API Integration", "CSS Animations", "Geolocation"],
        github: "https://github.com/yourusername/weather-app",
        live: "https://weather-app-demo.com",
        image: "https://via.placeholder.com/400x250/059669/white?text=Weather+App",
        featured: true
      },
      {
        id: 3,
        title: "Task Manager",
        description: "Collaborative task management tool with drag-and-drop functionality and real-time updates.",
        technologies: ["React", "Local Storage", "Drag & Drop", "Context API"],
        github: "https://github.com/yourusername/task-manager",
        live: "https://task-manager-demo.com",
        image: "https://via.placeholder.com/400x250/dc2626/white?text=Task+Manager",
        featured: false
      },
      {
        id: 4,
        title: "Portfolio Website",
        description: "Personal portfolio website built with React showcasing projects and skills.",
        technologies: ["React", "CSS3", "Responsive Design", "JavaScript"],
        github: "https://github.com/yourusername/portfolio",
        live: "https://yourportfolio.com",
        image: "https://via.placeholder.com/400x250/7c3aed/white?text=Portfolio+Website",
        featured: false
      }
    ],
    skills: [
      { name: "React", level: 85, category: "Frontend" },
      { name: "JavaScript", level: 90, category: "Frontend" },
      { name: "HTML/CSS", level: 95, category: "Frontend" },
      { name: "TypeScript", level: 70, category: "Frontend" },
      { name: "Vue.js", level: 60, category: "Frontend" },
      { name: "Sass/SCSS", level: 80, category: "Frontend" },
      { name: "Node.js", level: 65, category: "Backend" },
      { name: "Express.js", level: 60, category: "Backend" },
      { name: "MongoDB", level: 55, category: "Backend" },
      { name: "PostgreSQL", level: 50, category: "Backend" },
      { name: "Git", level: 80, category: "Tools" },
      { name: "Webpack", level: 65, category: "Tools" },
      { name: "Docker", level: 45, category: "Tools" },
      { name: "Figma", level: 70, category: "Tools" },
      { name: "Responsive Design", level: 90, category: "Frontend" },
      { name: "REST APIs", level: 75, category: "Backend" }
    ],
    experience: [
      {
        id: 1,
        company: "Tech Startup Inc.",
        position: "Frontend Developer Intern",
        duration: "Jun 2024 - Aug 2024",
        description: "Developed responsive web components using React and improved application performance by 30%.",
        achievements: [
          "Built 5+ reusable React components",
          "Implemented responsive design for mobile and desktop",
          "Collaborated with design team on UI/UX improvements",
          "Participated in code reviews and agile development process"
        ]
      },
      {
        id: 2,
        company: "Freelance",
        position: "Web Developer",
        duration: "Jan 2024 - Present",
        description: "Created custom websites for small businesses using modern web technologies.",
        achievements: [
          "Delivered 3 complete client projects on time",
          "Improved client website SEO rankings by 40%",
          "Maintained 100% client satisfaction rate",
          "Implemented responsive design and performance optimization"
        ]
      },
      {
        id: 3,
        company: "University Projects",
        position: "Student Developer",
        duration: "Sep 2023 - May 2024",
        description: "Completed various web development projects as part of computer science coursework.",
        achievements: [
          "Built full-stack web applications using MERN stack",
          "Collaborated on team projects using Git and GitHub",
          "Learned and applied software engineering best practices",
          "Achieved 95% average in web development courses"
        ]
      }
    ],
    education: [
      {
        id: 1,
        institution: "Your University",
        degree: "Bachelor of Science in Computer Science",
        duration: "2021 - 2025",
        gpa: "3.8/4.0",
        relevantCourses: [
          "Web Development",
          "Database Systems",
          "Software Engineering",
          "Data Structures and Algorithms",
          "Human-Computer Interaction"
        ]
      }
    ],
    certifications: [
      {
        id: 1,
        name: "React Developer Certification",
        issuer: "Meta",
        date: "2024",
        credentialId: "ABC123"
      },
      {
        id: 2,
        name: "JavaScript Algorithms and Data Structures",
        issuer: "freeCodeCamp",
        date: "2023",
        credentialId: "XYZ789"
      }
    ]
  };